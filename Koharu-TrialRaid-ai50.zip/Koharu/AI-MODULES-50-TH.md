# AI 50 โมดูล (Koharu-TrialRaid)

เพิ่มแท็บ **AI** ในเมนู GUI มีสวิตช์ 50 ตัว (กลุ่มละ 10) บวกโมดูลควบคุม `AIModules` อีก 1 ตัว
ตรรกะทั้ง 50 อยู่ใน `client/ai/modules/` เป็น Java ล้วน ไม่แตะ Minecraft จึงเทสต์ได้โดยไม่ต้องเปิดเกม

## ทำงานยังไง

1. `AiFrameBuilder` อ่านโลกในเกมหนึ่งครั้งต่อ tick เป็น `AiFrame` (ตัวเลขล้วน) **อ่านอย่างเดียว ไม่เขียนอะไรลงเกม**
2. `AiRegistry` รันเฉพาะโมดูลที่เปิดอยู่ แต่ละตัวคืน `AiAdvice` (ชนิด + ความเร่งด่วน 0..1 + ข้อความ)
3. `AiFusion` รวมคำแนะนำเป็น aggression / caution / dodge / heal (สเกลเดียวกับ `Planner.setLlmDirective`)
4. `AiModuleHub` วาด HUD และ (ตอนสวิตช์ `AIModules` เปิด) ส่งตัวดันเบาๆ เข้า `Planner.nudgeDirective` คูณด้วยค่า `Influence`
   ตัวกรองความปลอดภัยของ Planner ยังเป็นผู้ตัดสินเหมือนเดิม โมดูลเหล่านี้ไม่กดปุ่ม ไม่หมุนกล้อง ไม่สลับช่อง
5. ผลแพ้/ชนะจากจบแต่ละยก (`finishEpisode`) ถูกส่งกลับเป็น `feedback` ให้โมดูลที่เรียนรู้ (Win Predictor, Stance Bandit, Elo, Advice Trust ฯลฯ)
6. โมดูลที่ช้ากว่า 2 ms ต่อรอบเฉลี่ย (100 รอบ) หรือ throw ซ้ำ 3 ครั้ง จะถูกปิดอัตโนมัติพร้อมข้อความ (Module Health)

## ตั้งค่าที่ `AIModules`

| ตั้งค่า | ค่าเริ่มต้น | ความหมาย |
|---|---|---|
| Influence | 0.5 | น้ำหนักที่ส่งเข้า Planner (0 = ไม่ส่งเลย แสดงแค่ HUD) |
| HUD | เปิด | แสดงสรุปคำแนะนำกลางจอซ้าย |
| HUD Status Lines | 6 | จำนวนบรรทัดสถานะของโมดูลที่เปิด |
| Chat Narration | ปิด | พูดคำแนะนำสำคัญบน action bar (กันสแปมด้วย HUD Narrator) |

## รายการ 50 โมดูล

### Perception

| # | โมดูล | id | ทำอะไร | เปิดเริ่มต้น |
|---|---|---|---|---|
| 1 | Enemy Kalman | `enemy-kalman` | Smooths enemy motion and predicts where they will be in a few ticks. | ✔ |
| 2 | Aim Lead | `aim-lead` | Computes projectile intercept time/lead and warns when an enemy has a bow drawn. |  |
| 3 | Strafe Pattern | `strafe-pattern` | Detects periodic strafing (autocorrelation) so we can time hits to the turn-around. |  |
| 4 | Click Rate | `click-rate` | Measures the nearest player's swing rate (CPS). |  |
| 5 | Reach Estimator | `reach-estimator` | Learns the distance enemy hits really land from, to spot reach and set spacing. |  |
| 6 | Threat Assessor | `threat-assessor` | One threat number from distance, closing speed, health and armor. | ✔ |
| 7 | Burst Detector | `hit-confirm` | Sums damage taken over a short window and flags bursts. | ✔ |
| 8 | Ping Jitter | `ping-jitter` | Tracks latency mean and jitter and converts it to a timing margin. |  |
| 9 | Movement Intent | `movement-intent` | Labels the nearest player as approaching, fleeing, circling or holding. |  |
| 10 | Last Seen | `los-memory` | Remembers where a lost target was and how it was moving. |  |

### Combat

| # | โมดูล | id | ทำอะไร | เปิดเริ่มต้น |
|---|---|---|---|---|
| 11 | Engage Gate | `engage-gate` | Engage or retreat from health, totems and enemy strength, with hysteresis. | ✔ |
| 12 | Health Trend | `health-trend` | Estimates seconds until death from the recent HP slope. | ✔ |
| 13 | Totem Reserve | `totem-reserve` | Tracks totem count and raises caution when the reserve is thin. | ✔ |
| 14 | Burst Guard | `burst-guard` | Warns when one more big hit could kill. | ✔ |
| 15 | Crit Window | `crit-window` | Says when a critical hit is available. |  |
| 16 | Cooldown Sync | `cooldown-sync` | Holds attacks until the weapon is charged. |  |
| 17 | Combo Tracker | `combo-tracker` | Counts consecutive hits without taking damage. |  |
| 18 | Sprint Reset | `knockback-budget` | Suggests a sprint reset right after a hit to keep the enemy in range. |  |
| 19 | Target Picker | `target-switch` | Scores every nearby player and sticks to one unless another is clearly better. |  |
| 20 | Stance Bandit | `duel-bandit` | Learns which stance (press/patient/evasive) wins for you via Thompson sampling. | ✔ |

### Survival

| # | โมดูล | id | ทำอะไร | เปิดเริ่มต้น |
|---|---|---|---|---|
| 21 | Lava Guard | `lava-guard` | Warns when lava is close and escalates if we are in it. | ✔ |
| 22 | Void Edge Guard | `void-guard` | Warns about void below or a cliff ahead while moving fast. | ✔ |
| 23 | Fall Predictor | `fall-predictor` | Estimates fall damage and suggests a water bucket when it would hurt. | ✔ |
| 24 | Air Monitor | `drowning-monitor` | Watches the air supply. |  |
| 25 | Hunger Planner | `hunger-planner` | Decides when eating is worth the pause. | ✔ |
| 26 | Mob Swarm | `mob-swarm` | Counts hostile mobs and flags a swarm. |  |
| 27 | Creeper Alert | `creeper-alert` | Alerts when a creeper is within blast range. |  |
| 28 | Spawn Risk | `light-risk` | Flags dark spots where hostile mobs can spawn. |  |
| 29 | Storm Shelter | `storm-shelter` | Warns about lightning while exposed to the sky in a thunderstorm. |  |
| 30 | Gear Durability | `gear-durability` | Warns when armor or elytra are nearly broken. |  |

### Learning

| # | โมดูล | id | ทำอะไร | เปิดเริ่มต้น |
|---|---|---|---|---|
| 31 | Win Predictor | `online-logistic` | Logistic regression that learns P(win) from fight results. | ✔ |
| 32 | Aggression Tuner | `aggression-tuner` | Hill-climbs the aggression level that wins the most. |  |
| 33 | Advice Trust | `advice-trust` | Learns how reliable each kind of advice has been (Hedge algorithm). | ✔ |
| 34 | Experience Replay | `experience-replay` | Stores past fights and recalls how similar ones ended. |  |
| 35 | Archetype Cluster | `archetype-cluster` | Clusters opponents into aggressive / kiter / passive styles. |  |
| 36 | Change Point | `change-point` | CUSUM detector for a sudden change in enemy movement style. |  |
| 37 | Anomaly Detector | `anomaly-detector` | Flags enemy motion far outside what has been seen so far. |  |
| 38 | Difficulty Scaler | `difficulty-scaler` | Raises or lowers the suggested AI difficulty from your win rate. |  |
| 39 | Loss Reasons | `loss-reason` | Labels each loss (void, lava, fall, burst, attrition) and counts them. |  |
| 40 | Opponent Elo | `skill-elo` | Keeps an Elo rating for you and for each opponent you meet. |  |

### Assistant

| # | โมดูล | id | ทำอะไร | เปิดเริ่มต้น |
|---|---|---|---|---|
| 41 | Chat Intent | `chat-intent` | Understands short English/Thai chat orders like 'retreat' or 'หนี'. |  |
| 42 | Chat Mood | `chat-sentiment` | Tracks how hostile or friendly incoming chat is. |  |
| 43 | Command Suggester | `command-suggester` | Suggests the closest command or module when you mistype one. |  |
| 44 | Natural Commands | `natural-command` | Turns phrases like 'turn on totem reserve' into module toggles. |  |
| 45 | Prompt Compressor | `prompt-compressor` | Builds a compact situation summary for the LLM brain within a character budget. |  |
| 46 | LLM Validator | `llm-validator` | Repairs and range-checks the LLM's directive before it can touch the planner. |  |
| 47 | Advice Explainer | `advice-explainer` | Explains the current decision in a sentence (English or Thai). |  |
| 48 | Session Summary | `session-summary` | Collects fight statistics and writes a short report. |  |
| 49 | HUD Narrator | `hud-narrator` | Rate-limits AI messages so the HUD and chat never get spammed. | ✔ |
| 50 | Module Health | `module-health` | Times each AI module and auto-disables any that is too slow or throws repeatedly. | ✔ |

## ตัวอย่างการใช้งานในแชท
- พิมพ์ `หนี` หรือ `retreat` / `attack` / `กิน` → Chat Intent ส่งคำแนะนำเข้าตัวรวม
- พิมพ์ `.totem resrve` (พิมพ์ผิด) → Command Suggester เสนอ "Totem Reserve"
- พิมพ์ `turn on burst guard` / `disable lava guard` → Natural Commands สลับสวิตช์ให้ (ใช้ชื่อภาษาอังกฤษของโมดูล)

## สถานะการทดสอบ (ตรงไปตรงมา)
- **ทดสอบแล้ว**: ตรรกะของ 50 โมดูล + Fusion + Registry ผ่าน 134 เช็กใน `AiModulesSelfTest` (รันด้วย `./gradlew test` ผ่าน `AiModulesTests` หรือรัน main ตรงๆ)
  รวม fuzz 4000 tick ที่เปิดทุกโมดูลพร้อมกัน ไม่มี exception/NaN และค่า directive อยู่ในช่วง
  เทสต์เดิมยังผ่าน: `BrainSelfTest` 97/97 และ `AiCoreSelfTest` หลังแก้ `Planner`
- **ยังไม่ได้คอมไพล์/ลองในเกม**: ไฟล์ที่แตะ Minecraft ได้แก่ `AiFrameBuilder`, `AiModuleHub`, `AiFeature` และการต่อสาย 5 จุด
  (`KoharuClient`, `MinecraftAiRuntime`, `ChatScreenMixin`, `Category`, `Th`) เขียนจาก API ที่โค้ดเดิมใช้อยู่แล้ว
  แต่คอมไพล์กับ Minecraft ที่นี่ไม่ได้ ให้รัน `./gradlew build` แล้วลองในโลกทดลองก่อน
  API ที่โค้ดเดิมไม่เคยใช้และควรดู error ก่อน: `getAirSupply/getMaxAirSupply`, `isInLava/isInWater`, `hasLineOfSight`,
  `getMaxLocalRawBrightness`, `isThundering`, `getPlayerInfo(...).getLatency()`
- **Chat Mood** ยังไม่ได้รับข้อความแชทขาเข้า เพราะยังไม่มี hook ที่ยืนยันได้ (เรียก `AiFrameBuilder.pushIncomingChat(text)` จาก hook ใดก็ได้เพื่อเปิดใช้)

## ข้อจำกัดที่ควรรู้
- โมดูลเป็นฮิวริสติกและสถิติเบาๆ ไม่ใช่โมเดลภาษา ส่วน LLM จริงยังเป็น Ollama/LM Studio เดิม (`LlmBrain`)
  `Prompt Compressor` และ `LLM Validator` เป็นเครื่องมือเสริมให้สายนั้น แต่ยังไม่ได้ถูกต่อเข้า `LlmBrain` อัตโนมัติ
- ค่าที่เรียนรู้ (Win Predictor, Bandit, Elo ฯลฯ) อยู่ในหน่วยความจำ ไม่ถูกบันทึกลงไฟล์ ปิดเกมแล้วเริ่มใหม่
- Natural Commands รู้จักชื่อโมดูลภาษาอังกฤษเท่านั้น (คำสั่งเปิด/ปิดรองรับไทย)
- ชื่อโมดูลใน GUI ยังเป็นภาษาอังกฤษ ยังไม่ได้เพิ่มคำแปลใน `lang/th.txt`

## ไฟล์ที่เพิ่ม/แก้
เพิ่ม: `client/ai/modules/*` (13 ไฟล์), `module/impl/AiFeature.java`, `module/impl/AiModuleHub.java`, `test/.../AiModulesTests.java`
แก้: `Planner.java` (+`nudgeDirective`), `MinecraftAiRuntime.java` (+2 บรรทัด), `KoharuClient.java` (+1 บรรทัด),
`ChatScreenMixin.java` (+1 บรรทัด), `Category.java` (+`AI`), `Th.java` (+ชื่อแท็บ)
