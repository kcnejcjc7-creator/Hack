# Koharu AI brain (offline)

Backends (KoharuAI > LLM Backend): Built-in (default, in-process rules + learning), llama.cpp (in-process GGUF model,
put a .gguf in config/koharuclient/models/), Ollama / LM Studio (local servers, optional).

- Guard: every backend's answer is sanity-checked (no FIGHT at critical health, focus must be a real enemy, hazards force dodge).
- Learning: StanceBandit learns which stance wins in each situation; saved to config/koharuclient/ai/stance-bandit-v1.tsv.
- llama.cpp: output forced to valid JSON by a grammar, answers cached while the situation is unchanged, request rate adapts to model speed.
- Any failure falls back to the Built-in strategist; the game never waits on the model.

## Getting a model
In game run `/koharuai get-model` once: it downloads Qwen2.5-1.5B-Instruct Q4_K_M (~1.1 GB, Apache-2.0) from Hugging Face
into config/koharuclient/models/. The progress % shows above your hotbar; the result appears in chat. Then set LLM Backend = llama.cpp. After that everything is offline.

## Mace system (v163 rework)
Shared logic lives in `client/utils/MaceUtils.java` (smash bonus, armor-aware Breach/Density pick, shield-front check, axe->mace stun slam).
- AutoMace: equips the best mace before the dive ends, finds + aims at the target, hits when fall > min and cooldown ok (smart cooldown: smash bonus ignores cooldown), stun slam only when the shield really blocks.
- AutoWindcharge (keybind): jump -> wind charge at your feet at the top of the jump -> back to mace.
- AutoMaceCounter: simulates the diver's fall and throws a wind charge at the interception point (silent aim, same tick).
- BreachSwap: only swaps for a real smash against armored targets; Silent mode now actually attacks (it used to send an interact packet).
- LungeMaceBot / ElytraMaceBot: best-mace pick, axe-first on shields, smash only when the fall counts.

## Play styles (v165)
The built-in strategist now has 8 stances and learns a separate answer per opponent style (rusher, kiter, turtle, balanced).
Stances: PRESS, PATIENT, GUARDED, EVASIVE (old) + COMBO (w-tap chains), FLANK (circle-strafe), BAIT (s-tap counter), SHIELD_BREAK (axe vs shields).
Old learning files (stance-bandit-v1.tsv) are migrated on load; they are re-saved as v2.

## Fight To Death (v167)
`Fight To Death` (SwordAutoPlay or KoharuAI) makes the bot fight until someone dies: no retreat, flee, pearl escape or recovery trips.
Core: `client/ai/FightToDeath.java` (static flag + `remap(choice, state)`), hooks in `MinecraftAiRuntime`, `LlmBrain.guard`, `SwordAutoPlay`.
Heal In Fight / Auto Totem still work unless you turn them off. Explosions are still dodged.

## Berserk Mode (v168)
When health <= `Berserk Health` (default 16 = 8 hearts, leaves at +2) SwordAutoPlay switches to the berserk form (Fight To Death is implied: no retreat/flee/heal trips).
Pure logic lives in `core/BerserkEngine.java` (unit tests: `BerserkEngineTests`), the hook is `tickBerserk` / `bzAim` in `SwordAutoPlay`.
- Dodge: every enemy attack cycle (predicted by `SwordPredictor.attackIntent`, or a fresh swing) rolls `Berserk Dodge %` (default 98). A won roll opens a 6-tick dodge window where leaving the enemy's aim line outweighs everything else.
- Every step calculated: each tick all 16 headings + standing still are scored (danger from the enemy's view ray, own hit range, orbit toward the enemy's back, edge/lava safety) and the best one is walked.
- No-counter combo: orbit to the enemy's back, hit as soon as the sword is ~90% charged (no mistakes, no click delay, no crit jumps, no tap waits).
- 360 spin (`Berserk 360 Spin`): started so that the spin's last tick lands exactly on the target when the sword is ready (6 x 60 deg, then a correcting tick).
The 98% is the chance the bot reacts to an attack; whether the server still registers a hit depends on ping and the enemy's reach.
- W-Tap: after each swing in berserk the forward key is released for 1-3 ticks (needs the W Tap setting on) while strafe/dodge keys keep working.
