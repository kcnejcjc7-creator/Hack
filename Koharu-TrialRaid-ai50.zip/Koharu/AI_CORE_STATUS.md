# Koharu AI — implementation status

This is the integrated offline AI foundation added to the Fabric client source set. It is **not** a claim that the bot is already top-tier PvP or that every requested action is fully automated.

## Integrated components

### Perception
- `WorldModel`: per-player snapshots within 64 blocks, 40-tick history, smoothed position/velocity, health/absorption/armor/toughness, look angles, hands, swing/sprint/sneak/block/use/glide/ground flags.
- `MinecraftAiRuntime`: client-thread adapter for actual players and nearby rendered hazard entities (crystals, arrows, pearls, snowballs, eggs, tridents, wind charges, primed TNT).
- Local block snapshot cache identifies floor safety, lava, water, cobweb, obsidian, bedrock and forward wall. It is position-keyed, bounded, and refreshed each client tick; it is not a full chunk cache.
- `MinecraftCombatStats`: reads equipped-item attribute modifiers, Sharpness, Protection, Blast Protection and Resistance from Minecraft objects. Player attack damage is taken from the live attribute value, including active attribute modifiers.

### Prediction and threat
- `OpponentModel`: per-UUID style estimates, swing/facing/range/closing/motion signals and confidence-weighted linear/strafe/chase prediction.
- `ThreatMap`: reusable 0.5-block grid, 25×25 cells, five horizons, radial hazard scoring and armor/toughness/protection/resistance mitigation. The runtime uses expected damage sampled at the player's position for retreat decisions; the peak grid cell is shown only as a nearby hazard indicator. Crystal damage applies the multiplier used by the existing `CrystalAura` damage model.
- Crystal/TNT damage uses vanilla-style distance/exposure shape with a constant exposure estimate; it is not a full block-ray exposure calculation.

### Decision
- `Planner`: utility scores, win-probability caution/urgency, SEARCH/FIGHT/RETREAT/RECOVER modes, safety filtering, resource/crowd terms and 15% hysteresis.
- Planner produces a top-three ranking for the debug HUD and accepts a soft strategic directive from the local LLM (`LlmBrain`) only after hard safety filtering: mode hint (can only add caution), preferred action bonus (applied only when that action is already applicable), aggression/caution/dodge nudges.
- A group-risk rule triggers RETREAT when multiple nearby opponents are present and the player has no visible Totem or low combined health.
- Totem-pop windows alter risk for approximately 30 ticks: an opponent pop favors pressure; the player's pop increases caution.

### Execution and integration
- `InputPlanner`: maps each planner action to a mutually exclusive input intent.
- `HumanizedController`: log-normal reaction delay by difficulty and a smooth-rotation helper. The runtime currently uses the reaction delay to gate non-emergency plan changes; it does not directly replace `RotationManager` or write every input.
- `KoharuAI` has a `Shared Brain` setting (default on). While one of the four supported combat bots is active, the central runtime updates before that bot's tick. Set `Shared Brain` off to restore legacy-only behavior; alternatively toggle the `KoharuAI` module on to run the runtime and show its HUD.
- `SwordAutoPlay` consumes retreat and strafe hints; `AutoPlay` consumes retreat; `ElytraCrystalBot` consumes retreat via its existing REGROUP state; `ElytraMaceBot` consumes retreat via a safe retreat state.
- Legacy state machines continue to own attack timing, crystal routines, item swaps, rotation and key release. This intentionally avoids replacing those systems before live validation.

### Learning and persistence
- `EpisodeRecorder`: bounded episode event buffer and asynchronous file writer.
- `DefeatAnalyzer`: identifies the largest win-probability drop, applies temporal credit to earlier events and produces a compact report plus adjustment deltas.
- Defeat adjustments affect risk/retreat/dodge/aggression scoring within the running session.
- `OpponentMemory`: bounded, versioned per-UUID profiles saved in config.
- `Adapter`: per-opponent UCB1 strategy statistics persisted between sessions.
- The small MiniNet / replay-trainer / bundled zero-weight policy were removed. Online learning is the tabular `QLearner`, per-opponent `StatsTracker`/`Adapter` and defeat analysis.
- `LlmBrain` + `LlmPrompt` + `Json`: strategic layer backed by a language model running on this PC or LAN (Ollama or LM Studio). See `LLM_BRAIN.md`.

### Debug and controls
- Settings: Shared Brain, Debug HUD, Learning, Read Only, Difficulty, Risk Weight, Retreat Threshold, Adapter Interval, Lookahead settings and the LLM settings (LLM Brain, LLM Backend, LLM URL, LLM Model, LLM Interval, LLM Timeout, LLM Influence).
- HUD shows selected target/action, win estimate, threat, confidence, nearby players, hazard, top-three alternatives, damage dealt/received, LLM status/tactic and last defeat report.
- Client commands: `/koharuai clear-memory`, `/koharuai stats`, `/koharuai llm-status`, `/koharuai llm-test`.

## Config files

Created under `config/koharuclient/ai/` when the runtime initializes:
- `policy-v2.bin` — model weights
- `opponents-v1.tsv` — opponent profiles
- `adapters-v1.tsv` — per-opponent UCB1 statistics
- `replay-v1.bin` — online replay samples
- `episodes.tsv` — asynchronous episode event log
- `defeat-reports.txt` — defeat summaries

## Verification completed

- Java 21 pure-core compilation using `javac --release 21` — passed.
- `AiCoreSelfTest` assertions for damage helpers, WorldModel history, opponent estimate, ThreatMap, Planner, input intent, JSON parsing, LLM directive parsing/clamping, endpoint/host guards, planner directive hooks, bandit restore, episode recording, DefeatAnalyzer and OpponentMemory — passed.
- `tools/LlmBrainHttpTest.java`: round trip against mock Ollama and LM Studio servers (success, `<think>` output, HTTP 500, non-JSON reply, timeout, public-IP refusal, nothing listening) — passed.
- Note: run the self test with `java -ea`; without `-ea` the assertions are skipped.

## Known limits / not verified

- Full `./gradlew build` could not start compilation: the wrapper needs Gradle 9.2.1 and the environment could not resolve `services.gradle.org` (`UnknownHostException`). Minecraft-dependent sources therefore have **not** been confirmed by a full Fabric compile in this environment.
- No live Minecraft client/server or real PvP test was run.
- Planner uses heuristic utility scoring and hysteresis; a genuine 2–4 tick forward simulator/expectimax search is not implemented.
- The shared planner currently influences retreat/strafe and provides intents; it does not yet dispatch every planned action (pearl, heal, crystal placement, shield, fireworks, armor swap) into all four legacy state machines.
- Humanized reaction timing gates plan changes, but smooth rotation is not wired into `RotationManager`; attack/crystal CPS and action delays remain governed by the existing bots/modules.
- Threat estimates are approximate: projectile damage is fixed by type, crystal exposure is constant, enemy inventory is mostly unknowable client-side (only visible equipment/held Totems are counted), and shield direction/absorption interactions are not fully simulated.
- Opponent cooldown estimate uses recent swing timing, not a calibrated weapon-specific cooldown model. Style probabilities are heuristic and need fight data calibration.
- Block inspection is a small local position cache, not a bounded per-chunk cache or a complete safe-path/pearl-landing search.
- Elytra flight path, fall-distance kill threshold and exact armor-swap timing still rely on the original Elytra bots; the central planner only supplies retreat advice.
- Episode events include observed hurt/Totem signals and planner-selected actions; they cannot prove every suggested action was actually executed by the legacy bot.
- Online learning is bounded reward-driven regression, not a complete policy-gradient/Q-learning implementation. Checkpoint rollback is in-memory, and there is no self-play simulator or win-rate trend graph yet.
- The LLM layer has only been tested against mock servers. No real Ollama/LM Studio model, no live Minecraft client and no real fight were used. Reply quality, latency and usefulness of a 7B-class model for PvP are unmeasured.

Keep `KoharuAI`/Shared Brain disabled when testing legacy behavior only. Start with a private/local world and inspect the debug HUD before relying on the new tactical hints on a public server.


## Addendum — gap-filling pass (post-review)

Added (pure Java, covered by `AiCoreSelfTest`, run with `-ea`):
- `ForwardModel` — 1–4 tick expectimax-style lookahead (our action = max node; our hit / enemy hit = chance nodes; totem pop and death terminals). Heuristic constants, not physics. `Planner` adds `Lookahead Weight x (value(action) - value(NOOP))` for ATTACK, WAIT_CRIT, W_TAP, S_TAP, STRAFE, RETREAT, BLOCK, USE_COVER; depth auto-reduces when the moving average exceeds ~1 ms.
- `QLearner` — tabular Q-learning (1152 states x 19 actions), bounded bias in `Planner`, ignored until a cell has >= 5 samples, versioned/validated file `qtable-v1.bin`; reward = damage dealt - 1.2 x damage taken (+/-4 on win/loss). No random exploration in live play.
- `StatsTracker` — per-opponent fights/wins/damage and rolling win-rate trend (`stats-v1.tsv`), shown on HUD and via `/koharuai stats`.
- `ActionLimiter` — one action per tick, randomized CPS windows (attack 8–14, crystal 6–10), jittered swap gaps.
- `SelfPlaySim` — off-game duel simulator (`java ...ai.SelfPlaySim [episodes] [qfile]`).
- New settings: `Lookahead Depth` (0–4), `Lookahead Weight`.

Still NOT done / not verified:
- `ActionLimiter` exists but is not yet called by the four legacy bots; they still own click timing.
- `HumanizedController.smoothDelta` is still not wired into `RotationManager`.
- Self-play sim: lookahead made no measurable difference there (ATTACK dominates in that toy world), so the sim does not prove lookahead helps in real PvP.
- Pearl/crystal-placement/armor-swap/firework dispatch, Elytra flight physics, and block-ray crystal exposure remain unimplemented.
- Minecraft-dependent files (runtime wiring, KoharuAI, bots) have never been compiled by Gradle here.
