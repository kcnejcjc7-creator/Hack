# Koharu v146 — AI implementation report

## Summary

The source package now contains a shared offline AI runtime, a Minecraft perception adapter, tactical integration points for all four requested combat bots, persistent learning data, an optional local-LLM strategy layer (replacing the earlier MiniNet), debug controls, and dependency-free regression tests.

This is a substantial integration pass, not a completed top-PvP agent. The central planner currently supplies tactical retreat/strafe guidance while the existing bots continue to execute attacks, crystal sequences, equipment swaps and rotation. Full action ownership was deliberately not transferred because the Fabric build could not be run here and the existing bots contain long state machines and cleanup paths.

## Changed / added files

### New
- `src/client/java/com/koharu/koharuclient/client/ai/WorldModel.java`
- `src/client/java/com/koharu/koharuclient/client/ai/DamageModel.java`
- `src/client/java/com/koharu/koharuclient/client/ai/MinecraftCombatStats.java`
- `src/client/java/com/koharu/koharuclient/client/ai/MinecraftAiRuntime.java`
- `src/client/java/com/koharu/koharuclient/client/ai/OpponentModel.java`
- `src/client/java/com/koharu/koharuclient/client/ai/ThreatMap.java`
- `src/client/java/com/koharu/koharuclient/client/ai/Planner.java`
- `src/client/java/com/koharu/koharuclient/client/ai/InputPlanner.java`
- `src/client/java/com/koharu/koharuclient/client/ai/HumanizedController.java`
- `src/client/java/com/koharu/koharuclient/client/ai/LlmBrain.java`, `LlmPrompt.java`, `Json.java`
- `src/client/java/com/koharu/koharuclient/client/ai/EpisodeRecorder.java`
- `src/client/java/com/koharu/koharuclient/client/ai/DefeatAnalyzer.java`
- `src/client/java/com/koharu/koharuclient/client/ai/OpponentMemory.java`
- `src/client/java/com/koharu/koharuclient/client/ai/Adapter.java`
- `src/client/java/com/koharu/koharuclient/client/ai/AiCoreSelfTest.java`
- `src/client/java/com/koharu/koharuclient/client/module/impl/KoharuAI.java`
- `LLM_BRAIN.md`, `tools/LlmBrainHttpTest.java`, `tools/Tune.java`

### Modified
- `src/client/java/com/koharu/koharuclient/client/KoharuClient.java` — register shared module first, shutdown persistence hook and client commands.
- `src/client/java/com/koharu/koharuclient/client/module/impl/SwordAutoPlay.java` — consume shared retreat/strafe hints.
- `src/client/java/com/koharu/koharuclient/client/module/impl/AutoPlay.java` — consume shared retreat hint through existing FLEE path.
- `src/client/java/com/koharu/koharuclient/client/module/impl/ElytraCrystalBot.java` — consume shared retreat hint through existing REGROUP path.
- `src/client/java/com/koharu/koharuclient/client/module/impl/ElytraMaceBot.java` — consume shared retreat hint through new safe retreat state.
- `AI_CORE_STATUS.md` — accurate implementation and limitation inventory.

## Phase summary

| Phase | Status | Notes |
|---|---|---|
| WorldModel + damage | Implemented baseline | Live player/hazard observation, 40 tick history, smoothing, ItemStack attack/protection enchantment extraction; exposure remains approximate. |
| OpponentModel + ThreatMap | Implemented baseline | Heuristic probability/style/motion prediction and 0.5-block hazard grid; no calibrated weapon cooldown. |
| Planner | Implemented partial | Utility ranking includes win-probability caution/urgency, SEARCH/FIGHT/RETREAT/RECOVER modes, safety filter, 15% hysteresis, crowd/resource and top-three scoring; no forward-model expectimax. |
| Execution/Humanization | Implemented partial | Input intent map and difficulty response gate; not a full controller for keys/RotationManager. |
| Bot integration | Implemented partial | Four bots receive tactical guidance but preserve their own action executors. |
| Recorder/Defeat/Memory | Implemented baseline | Asynchronous episodes, temporal analysis, report files and opponent profiles. Event attribution is based on observable signals. |
| Adapter | Implemented baseline | Per-opponent UCB1 with persistence. |
| Local LLM strategist | Implemented, mock-tested only | Async Ollama / LM Studio client, clamped soft directive with expiry, safety-filtered planner hooks. MiniNet removed. |
| Debug/statistics | Implemented partial | Debug HUD, top-three plans, win/threat/confidence and damage values; no long-term graph. |

## Build result

Command attempted:

```bash
./gradlew build --no-daemon
```

Result: failed before Gradle could launch because the wrapper download was blocked by DNS resolution:

```text
Downloading https://services.gradle.org/distributions/gradle-9.2.1-bin.zip
java.net.UnknownHostException: services.gradle.org
```

The dependency-free Java subset and Python/Java weight-format interoperability tests passed. The latest regression run also covers damage at the player's position in the threat grid, action intent conflicts, and rejection of out-of-range model/bandit values. This does not substitute for a full Fabric build.
