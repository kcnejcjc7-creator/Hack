# Koharu + Anubis — full source integration package

## What is in this package

- Koharu project remains the outer Fabric mod and keeps its Survival Autopilot code.
- The complete supplied Anubis 0.9.9 source snapshot is now extracted into `anubis/src/main/java`: **604 Java source files**, including the complete `net.anubis` implementation and `com.example` mixin package.
- Anubis has its own Gradle subproject using Fabric Intermediary mappings because the supplied source refers to Minecraft as `class_####`, `method_####`, and `field_####`. This isolates its mappings from Koharu's Mojang-mapped sources.
- The root Koharu JAR task embeds the Anubis output under `META-INF/jars/`, and the outer `fabric.mod.json` declares the nested mod. The intended installation is one outer Koharu `.jar`; Fabric Loader loads the nested Anubis mod from it.
- ImGui binding versions are aligned at 1.90.0. Anubis's declared ImGui, Netty proxy, JNA, and Commons Lang dependencies are included in its nested mod build.
- The original `Anubis-0.9.9-source.zip` and its GPL license are retained under `third_party/` / `anubis/`. The source archive SHA-256 is `0b0f03bb8c429b2269bc9c52aefce4523548529f33e2c702ab0d6b3bdcdbc4df`, matching the checksum published by the Anubis source page.

## Important build limitation

The supplied Anubis ZIP is explicitly a **source snapshot, not a complete build repository**. It contains 604 Java files and metadata/mixin JSON, but does not contain the complete original artwork/resource bundle (for example the original bundled character `.anc` files and original fonts/textures). This package provides basic fallback font/texture assets so the core client resources are present; these are not the original Anubis artwork. The two baked character files `cj.anc` and `neighbor.anc` are not included.

The code is imported in full rather than selectively dropping the 25 pending or 17 visual modules from the previous inventory. Some original features may still need their omitted binary assets or dependency details to be fully functional.

## Validation

Run `python tools/verify_anubis_full_import.py` to confirm all 604 Java files, both Anubis mixin configs, license, and nested-mod metadata are present.

The full Gradle build has **not** been verified in this environment because Gradle 9.2.1 could not be downloaded (`services.gradle.org` DNS resolution failed). GitHub Actions will attempt `./gradlew clean test build --no-daemon`; a green workflow and in-game smoke test are still required before calling this a working release JAR.

## Credits and license

Anubis source remains under GPL-3.0-only. Preserve `anubis/LICENSE_anubis` and the credit to the Anubis project authors (Horus / 4ldenz). Koharu's own license and third-party notices remain in place.
