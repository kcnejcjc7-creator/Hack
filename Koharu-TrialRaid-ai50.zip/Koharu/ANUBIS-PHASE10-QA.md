# Koharu + Anubis — Phase 10 hardened QA report

**Target:** Minecraft 1.21.11, Fabric client, Java 21 compile target.

## What changed in this delivery

- Hardened `CoordSnapper`: isolated coordinate formatting; validates dimension resource locations before creating dimension-aware command text; a looked-at block is offset upward only for `/tp` output.
- Hardened `RenderDistanceToggle`: isolated lifecycle policy; clamps render distance to 2–32, restores the original setting after 10 ticks, on world exit, dimension change, or module disable; requires crossing above the threshold plus a 2-block margin before re-arming.
- Added pure-Java helpers `CoordSnapperFormat` and `RenderDistancePolicy`, plus `AnubisPortRulesSelfTest` (35 assertions).
- Added `tools/run-anubis-port-qa.sh` to repeat focused policy tests 10 rounds and run the wider offline regression suite.

## Verification results

| Test | Result |
|---|---|
| Focused policy tests | 35/35 per round, 10/10 rounds (350/350 executions) |
| Structural integration checks | 13/13 per round, 10 rounds (130/130 executions) |
| `AiCoreSelfTest` | Passed |
| `SurvivalSelfTest` | Passed |
| `CrystalPvpSelfTest` | 27 checks passed |
| `TouchScrollTest` | Passed |
| `LlmBrainHttpTest` | All mock HTTP cases passed |
| Thai translation check | 100%, 0 missing |
| Full Gradle/Fabric build | Blocked before Gradle starts: DNS failure resolving `services.gradle.org` for Gradle 9.2.1 |
| Minecraft client / server smoke test | Not performed |

## Scope status — not a complete 121/121 merge

The Anubis archive contains 608 files, 236 Java files under `module/impl`, and 121 module classes. The inventory table currently classifies 120 entries: 27 ported, 51 matched by existing Koharu equivalents, 25 still pending, and 17 heavy character/cosmetic/render modules held back. The held-back 17 are 3D visual/model features, not LLMs. Anubis source uses its own `ClientModule`, EventBus and settings framework plus intermediary `class_####` names; Koharu uses its own module API and Mojang mappings. A bulk copy would not compile or provide reliable behavior.

No Anubis LLM or AI-model download/runtime dependency was added. Koharu's pre-existing Llama/LLM code and dependencies were not changed.

## Release decision

**Source update: delivered. Full mod release: not verified.** This environment cannot download the Gradle distribution, so it cannot produce a tested `.jar`. The following command must succeed in an environment with repository access before calling this build usable in Minecraft:

```bash
./gradlew clean test build --no-daemon
```

Then launch Minecraft 1.21.11 on a backup profile and smoke-test the new modules in a local world and on the target server. The offline checks above do not establish in-game compatibility or guarantee zero bugs.
