# Brain Hub: สมองวิเคราะห์ 7 แกน

แพ็กเกจ `client/ai/brain/` (Java ล้วน ไม่พึ่ง Minecraft) ต่อเข้ากับ `MinecraftAiRuntime` → `Planner` เดิม
เปิด/ปิดที่ KoharuAI → `Brain Hub`, ปรับน้ำหนักที่ `Brain Influence` (0 = ปิดผล)

| โมดูล | ไฟล์ | ทำอะไรในสายการตัดสินใจ |
|---|---|---|
| Mathematical | `MathematicalAiCore` | เมทริกซ์/แก้ระบบสมการ, อนุพันธ์/อินทิกรัล, RK4, Nelder-Mead, จำนวนเฉพาะ, FFT, พหุนามเชิงสัญลักษณ์, BigDecimal, เวลาดักชน (intercept) |
| Predictive | `PredictiveAiCore` | Kalman ติดตามศัตรู, Holt/AR/Seasonal, ทำนายท่าถัดไปด้วย Markov อันดับ 2, ensemble ที่ลดน้ำหนักโมเดลที่ทายพลาด |
| Scientific | `ScientificAiCore` | ฟิสิกส์/เคมี/ชีวะ/ดาราศาสตร์/ควอนตัม + ฟิสิกส์ Minecraft (ตกจากที่สูง, ลูกธนู, สูตรเกราะ) |
| Financial | `FinancialAiCore` | Kelly, VaR/ES, Black-Scholes, พอร์ตโฟลิโอ, RSI/MACD, และ `resourceValue` ประเมินคุณค่าของ Totem/ของที่ต้องเก็บไว้ |
| Probability | `ProbabilityAiCore` | Bayes, Beta (Thompson), ช่วงความเชื่อมั่น Wilson, Monte Carlo, Markov, ทดสอบสมมติฐาน |
| Simulation | `SimulationAiCore` | ดวล Monte Carlo 20 tick/วิ, free-for-all, what-if, "ฝาแฝดดิจิทัล" ของศัตรูที่เรียนรู้จากการสังเกต |
| Strategic | `StrategicAiCore` | เกมศูนย์ผลรวม (Nash), decision tree, Pareto, knapsack, A*, Exp3/Thompson, regret |

`BrainHub.think()` เรียงตามนี้: ติดตาม+ทำนาย → ตารางผลตอบแทน 3×3 (PRESS/PATIENT/EVASIVE × RUSH/KITE/TURTLE)
จากการจำลองจริงรวมค่า "รอดชีวิต" → Nash ผสมกับ best-response ตามความคาดเดาได้ของศัตรู → ขนาดการลงแรงด้วย Kelly
→ ส่ง `Directive` เข้า `Planner.setLlmDirective` (ตัวกรองความปลอดภัยของ Planner ยังชี้ขาดเหมือนเดิม)
คิดบนเธรดแยก (`koharu-brain`) ใช้เวลา ~50–60 ms ต่อรอบ เกมไม่รอ

## ข้อจำกัดที่ต้องรู้
- **ไม่ได้ "รู้อนาคต"** ทุกค่าที่ออกมาเป็นการประมาณพร้อมช่วงความไม่แน่นอน ศัตรูที่เล่นสุ่มจะทายไม่ได้ (ทดสอบแล้ว predictability ≈ 0)
- โมเดลดวลง่าย (อัตราโดน × ดาเมจ × คูลดาวน์ + Totem + กินยา) ใช้จัดอันดับทางเลือก ไม่ใช่ตัวจำลองเซิร์ฟเวอร์เป๊ะๆ
- Financial/Scientific เป็นไลบรารีสูตร ไม่ได้ทำนายตลาดหรือแทนห้องแล็บ และ sentiment เป็น lexicon พื้นฐาน
- Hit chance ของเราตั้งต้นที่ 0.65 (ยังไม่ได้ถูกเรียนรู้จากการเล่นจริง)
- **ยังไม่ได้ build/ลองในเกม**: ชั้น `brain/` คอมไพล์และผ่านเทสต์ 97 ข้อ (รัน `BrainSelfTest` หรือ `./gradlew test`)
  แต่ส่วนที่แตะ Minecraft (`MinecraftAiRuntime`, `KoharuAI`) เขียนจากโค้ดที่มีอยู่โดยคอมไพล์กับ Minecraft ไม่ได้ ให้ `./gradlew build` แล้วลองในโลกทดลองก่อน

## ที่แก้จากโค้ดเดิม
`MinecraftAiRuntime.java` (ฮุคเล็กๆ: observe / directive / requestAsync / feedback), `KoharuAI.java` (+2 การตั้งค่า), `lang/th.txt` (+2 คำแปล)
