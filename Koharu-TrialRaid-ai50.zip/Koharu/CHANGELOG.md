## AI 50 modules
- New AI tab with 50 switchable advisory modules (perception, combat, survival, learning, assistant) plus the AIModules hub; see AI-MODULES-50-TH.md. Planner gets a bounded `nudgeDirective`; fight outcomes feed the learning modules.

## Anubis integration Phase 10 — hardened feature policy and offline QA
- Hardened `CoordSnapper` with pure formatting/validation rules; looked-at block positions are raised only for `/tp` output.
- Hardened `RenderDistanceToggle` with a tested state policy: restore on timeout, disable, world exit, or dimension change; re-arm only after clearing the configured Y threshold by 2 blocks.
- Added 35 pure-Java regression assertions; focused tests and structural checks passed 10 rounds. Wider AI, survival, CrystalPvP, touch-scroll, mock HTTP and Thai checks passed once.
- Full Fabric build remains blocked because this environment cannot resolve `services.gradle.org`; no tested JAR or live Minecraft smoke-test is claimed. Full Anubis 121-module merge remains incomplete; see `ANUBIS-AUDIT-TH.md` and `ANUBIS-PHASE10-QA.md`.

## Anubis audit + two modules
- Audited Anubis 0.9.9 (no malware signs found; plaintext account tokens noted). See ANUBIS-AUDIT-TH.md.
- New modules: `AutoReplenish` (hotbar refill, plain inventory clicks, yields to SurvivalBot crafting via `SurvivalBot.inventoryBusy()`), `LowHealthWarning` (HUD vignette).
- Thai: translations for the new strings + 8 previously missing keys (check_thai = 100%).
- Not built against Minecraft here; syntax-checked only.

## Survival phase 4 - portal + Nether loot
- `survival/PortalPlan` (pure, tested): 2x3 portal, 10 obsidian, 3 cobblestone scaffold blocks, every block has a support when placed.
- `SurvivalBot`: new PORTAL phase (site search, clear, build, strip scaffold, light, enter) + HUD dimension/sub-step.
- `SurvivalPlanner`: gold nuggets/ingots, ancient debris -> scrap -> netherite ingot, kit NETHER_LOOT (6 ingots); NETHER_READY now also carries cobblestone, coal, table, furnace.
- `CampaignPlanner`: NETHER_PORTAL and NETHER_LOOT are automated; flag `portal_built`.
- Not built against Minecraft here (no Gradle deps); pure-Java survival self-test passes, SurvivalBot syntax-checked only.

## v167 - Fight To Death + Thai pass
- New setting **Fight To Death / สู้จนตัวตาย** in `SwordAutoPlay` and `KoharuAI` (default off; either one turns it on for every bot that uses the shared brain).
  When on the bot never retreats, never flees, never pearl-escapes and never walks off to recover: `danger()` and soft retreat are off, `enterRetreat()` keeps the
  state at FIGHT, `tickRetreat()`/`tickRecover()` go straight back to FIGHT, aggression is forced to 1.0, the AI brain's RETREAT/RECOVER/PEARL_ESCAPE/USE_COVER/NOOP
  decisions are remapped to ATTACK (`ai/FightToDeath.remap`) and the LLM guard no longer vetoes FIGHT at critical health.
  Still allowed: eating/totem in the fight (Heal In Fight, Auto Totem), lethal-explosion dodging, edge/lava safety, wind/web escape.
  Turn off `Heal In Fight` / `Auto Totem` too if you want a pure no-heal duel.
- Thai: the last menu string ("Sweep vs Groups") + 7 module descriptions + all combo option values (Off, Chat, Action Bar, ...) + AI action/mode names translated;
  in-game SwordAI messages, fight lessons, KoharuAI debug HUD, `/koharu*` command feedback, model download status and the crash notice now use `Th.tr` (follows GUI > Language).
  `tools/check_thai.py --max-missing 0` passes (100%). Other bots' (Crystal/Elytra/Mace/Survival) chat logs are still English.
- `ModelDownloader` stays pure Java: translation goes through a hook (`tr0`) that the game side sets.
- `AiCoreSelfTest` has new Fight To Death assertions. Not built against Minecraft here (no Gradle deps); the pure-Java AI core compiles and the self-test passes.

## v166 - sword guide rules
- New `sword/SwordRules` (pure Java, unit-tested): tier damage/durability incl. copper, Sharpness bonus, charge scale, Sweeping Edge ratio,
  hit classification (crit / sprint knockback / sweep are mutually exclusive as in the guide), and `sweepBeatsCrit`.
- SwordAutoPlay: new setting "Sweep vs Groups" (default on). When bystanders stand around the target and a grounded sweep out-damages a single crit
  (needs Sweeping Edge, or several bystanders), the bot stops chasing crits and releases sprint for the swing (sprint knockback cancels a sweep).
- Guide vs vanilla: the guide quotes 84.8% charge for crit/sprint-KB/sweep; vanilla checks "> 0.9", and the bot keeps 0.9 (`SwordRules.CHARGED`).
- Not built against Minecraft here (no Gradle deps); only syntax-checked. Pure-Java AI core + SwordRules tests pass.

## v165 - AI play styles
- StanceBandit: 4 -> 8 stances (added COMBO, FLANK, BAIT, SHIELD_BREAK); separate learning table per opponent play style
  (UNKNOWN / RUSHER / KITER / TURTLE / BALANCED); faster adaptation (the learned mean follows the last ~10 results per cell).
  Save format v2; v1 files load automatically.
- New OpponentArchetype: classifies the focus enemy from aggression, retreat rate and how often it blocks.
- LocalStrategist: style-aware favourite stance; new stances only open when they make sense (no COMBO/PRESS while hurt,
  SHIELD_BREAK only against shield users, FLANK/BAIT only with <2 enemies close); FLANK alternates left/right.
- LlmPrompt: local model is told about the new tactics (W_TAP, STRAFE, S_TAP bait, SWITCH_AXE).
- Tests: AiCoreSelfTest extended (styles, v1 migration, adaptation, safety with every stance). Pure-Java AI core compiles and passes;
  the Minecraft-dependent code was NOT built here (no Gradle/Loom network) - build it on your side.

# Unreleased (v164 stability pass)

Not built against Minecraft in the sandbox (no Gradle/Fabric deps there). Verified: `core` JUnit tests (19), `AiCoreSelfTest`, `tools/check_thai.py`, and a javac syntax check of the edited client files. Run `./gradlew build` and a live-game smoke test before releasing.

- New `core/` package (no Minecraft dependency, unit-tested): `KLog` (file + console log, rotated at 1 MB), `ModuleGuard` (crash guard + per-module timing), `ConfigBackup`, `ConfigMigrator`, `ProfileStore`.
- Crash guard: every module `tickKeybind`/`onTick` runs through `ModuleGuard`. An exception is logged instead of propagating; 3 failures within 40 ticks disables that module and tells the player (it stays quiet until re-enabled). Log: `config/koharuclient/logs/koharu.log`.
- Profiler: `/koharuperf` shows average/peak ms per module and error counts; slow modules (>0.5 ms avg) are also logged once a minute.
- Config: atomic writes (no half-written file on crash), up to 10 rolling backups in `config/koharuclient/backups/`, automatic recovery from the newest good backup when `config.enc` is unreadable (the broken file is kept as `config.enc.corrupt`), `SchemaVersion` + migration chain (`ConfigManager.MIGRATOR`, add a step when a setting is renamed).
- Profiles: `/koharuprofile save|load|delete <name>` and `/koharuprofile list` (`config/koharuclient/profiles/`).
- Cleanup: 24 `System.out/err.println` and `printStackTrace()` calls replaced by `KLog` (macros, shaders, NanoVG, target filters, crypto, window config); `Module` constructors chained instead of copy-pasted; `ModuleManager.getModule` uses a name index (with the old linear scan as fallback).
- `SwordAutoPlay` (2,620 -> 2,516 lines): the UCB1 bandit moved to `core/UcbBandit` and the A* pathfinder to `core/GridPathfinder` (world access via a small `Grid` interface). Both are pure Java with 9 new unit tests (`SwordCoreTests`: arm coverage, convergence, decay, straight path, wall, holes, unreachable goal, node budget). Behaviour is meant to be identical; the search logic was moved line for line.
- Removed unused GUI code: `NewClickgui`, `ReworkedClickgui` and `ui/reworked/*` (about 2,900 lines, nothing referenced them). Still present and worth consolidating next: `KoharuGUI` (only kept for panel positions in ConfigManager), `BoxGui`, `LegacyUI`, `ImGuiClickGui`.
- Thai: 97 missing translations added; `tools/check_thai.py` reports coverage and CI fails if a new string has no translation.
- CI: `.github/workflows/tests.yml` runs the core tests, `AiCoreSelfTest` and the Thai check on every push, plus `./gradlew test`.
- build.gradle: JUnit 4 + vintage engine for the `core` tests.

# Unreleased

- Merged `koharu-ai-patch` into the v161 AI-live base (details in the bullets below). Untested in a live game; full Gradle build not run (no Minecraft/Fabric deps in the sandbox). Pure-Java AI core compiles and `AiCoreSelfTest` passes.
- AI: removed the small `MiniNet` / `MiniNetTrainer` / bundled policy / Python trainer and the `/koharuai export-model|import-model` commands and their settings. Added `LlmBrain` (local Ollama / LM Studio strategist, see `LLM_BRAIN.md`), settings `LLM Brain/Backend/URL/Model/Interval/Timeout/Influence`, commands `/koharuai llm-status|llm-test`. `Planner` gained soft LLM hooks and tuning constants (`setTuning()/tuning()`, defaults unchanged) + anarchy rule (>=3 enemies and low total EHP -> RETREAT, pearl-escape bonus when crowded); `SelfPlaySim` double Q-update fix + 8% exploration.
- `LungeMaceBot`: ground melee while not airborne, always closes distance, `Flee When Low`, pearl opener only when target > 12 blocks, pitch locked to 0 on lunge, hunger/elytra/water checks, `Fall Save`, target lock.
- `ElytraMaceBot`: `Disable No Target` + `No Target Seconds`; every disable path goes through a safe glide-down landing and re-equips armor before turning off.
- `tools/Tune.java`: offline random-search tuner for the Planner constants (not part of the build).

- Added `CrystalPvpBot` (see CRYSTAL_PVP.md). Untested in a live game; full Gradle build not run.

# Koharu Client v3.1 Changelog

This is a minor release (v3.1) adding the new WebStun module and improving the LungeAssist module.

## 🚀 New Features

### **WebStun**
- **Automatic Cobweb Placement:** Places a cobweb directly under target player's feet when their shield is disabled by AutoShieldBreaker or when hit.
- **Anti-Cheat Safe:** Spans actions across multiple ticks using a multi-tick state machine.
- **Silent Rotations & Placements:** Uses exact GCD-snapped rotations and post-movement callbacks to place blocks against solid support blocks, preventing GrimAC alerts.

## 🛠️ Bug Fixes & Improvements

### **LungeAssist**
- **Jumping Apex Logic:** Fixed LungeAssist so that if enabled while jumping/falling, it waits for the apex of the jump before initiating the spear lunge attack.
- **GPL-3 Compliance:** Updated base implementation to align with project licensing constraints.

### **Bypass Infrastructure**
- **MultiPlayerGameMode client-carried sync:** Prevented duplicate selection packets (BadPacketsA bypass) by reflectively syncing carried index fields.
- **Mixin Optimization:** Replaced static mixin fields with localized manager references to prevent loader crashes.

## phase 6
- Anubis port #2: Speed, Spider, Jesus, AirStuck, EntitySpeed, AutoJump, Sneak, FastXp, AutoEat, ChatSpam; Flight gets Velocity mode + Anti Kick. See ANUBIS-AUDIT-TH.md.
- Anubis port #3: ClickTp, GrimNoFall (ConnectionMixin hook), StaffWatch, AntiVanish.
- Anubis port #4: GrimRiptide, PlayerBypass (light-packet underground finder; 2 hooks in ClientGamePacketListenerMixin).
- Anubis port #5: Zoom, WeatherNotifier, TridentBoost, NetheriteFinder; full status table in ANUBIS-AUDIT-TH.md.

## Anubis import phase 10 (Koharu 1.21.11)
- Added `CoordSnapper`: configurable edge-triggered clipboard copy for looked-at/current coordinates, dimension suffix, and `/tp` output.
- Added `RenderDistanceToggle`: lower local render distance below a configured Y level, then restore the previous value; cleanup on disable/world change.
- Added Thai strings for both modules' settings.
- Added `tools/verify_anubis_phase10.py` (10 structural checks). It passed 10 consecutive runs; `AiCoreSelfTest` and Thai coverage passed.
- Full Fabric build is still unverified: Gradle 9.2.1 could not be downloaded in the offline environment. This phase is a partial port, not a claim that all Anubis modules have been integrated. See `ANUBIS-AUDIT-TH.md`.

## Unified UI
- Anubis GUI/menus/HUD/loading screen disabled; its modules are bridged into the Koharu menu as "Anubis <name>" (AnubisBridge, reflection-based).
