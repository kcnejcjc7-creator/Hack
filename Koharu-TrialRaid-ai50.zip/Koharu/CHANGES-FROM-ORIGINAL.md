# Changes vs koharu-v163-llm-brain (original)

Added:  ai/LocalStrategist.java, ai/StanceBandit.java, ai/LlamaCppEngine.java, ai/ModelDownloader.java, AI-NOTES.md
Edited: ai/LlmBrain.java, ai/LlmPrompt.java, ai/MinecraftAiRuntime.java (small hooks), KoharuClient.java (/koharuai get-model), ai/AiCoreSelfTest.java,
        module/impl/KoharuAI.java, build.gradle (de.kherud:llama:4.1.0)
Everything else is byte-identical to the original.
Verified: pure-Java AI package compiles, AiCoreSelfTest + LlmBrainHttpTest pass.
Not verified: full Gradle build, in-game play, real llama.cpp model run.

GUI (touch fix): clickgui/BoxGui.java (drag-to-scroll in all 3 columns, category scrolling, scroll bars, ">" tap = open settings,
actions fire on release, window max height 400), clickgui/TouchScroll.java (new), tools/TouchScrollTest.java.


LungeMaceBot fix: Wind Jump Gap (run-in launch, no standing launch from far away), fleeing-target gate, enemy-mace sidestep, Retreat Health 8, no axe melee while rising. Not compiled in-game. Sim: tools/Sim.java, tools/SimGap.java.

LungeMaceBot x KoharuAI: MinecraftAiRuntime.hasActiveCombatBot now includes LungeMaceBot (runtime/learning/stats run for it). LungeMaceBot: AI Retreat (planner RETREAT must persist 5 ticks, conf>=0.3), AI Debug diagnostics line, per-tick try/catch (stops after 5 errors), conflict check with other bots, learned lunge stats kept across enables. Not compiled.

ElytraSpearBot (new, Mace category) + SmoothAim (utils): velocity/acceleration-limited camera used by ElytraSpearBot, ElytraMaceBot, LungeMaceBot; SwordAutoPlay aim got an acceleration limit. Crash guard in ElytraSpearBot. Syntax-checked with javac only; not built with Gradle, not tested in game.
