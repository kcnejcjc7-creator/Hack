# CrystalPvpBot (Koharu, Minecraft 1.21.11 Fabric)

Module `CrystalPvpBot` (category Crystal) is a crystal-PvP decision loop built on top of the existing crystal modules.

## What it reuses (not rewritten)
| Existing code | Used for |
|---|---|
| `AutoPlaceCrystal.canHoldCrystal` | crystal placement legality (made package-static) |
| `CrystalAura.exposure` / `canSeeFace` | ray-cast explosion exposure and face visibility (made package-static) |
| `AutoTotem.findTotemSlot` / `triggerInputPause` | offhand totem re-equip, input pause (made package-static) |
| `ModuleUtils` | silent same-tick swaps, hotbar lookup, rotations |
| `RotationManager` | smooth server-side aim, ownership check |
| `CrystalHelperRules.cooldownElapsed` | action cooldown |
| `TotemPopTracker` | pop counts for us and the enemy |
| `MinecraftCombatStats` + `ai.DamageModel` | armor / toughness / Protection / Blast Protection / Resistance, explosion curve |

New pure logic lives in `utils/CrystalPvpRules.java` (damage composition, own-blast rule, scoring, stance, D-tap sequencer) with `CrystalPvpSelfTest`.

## Loop
find nearest valid player -> pick best action by (enemy damage - 0.5 x self damage, kill bonus) ->
break existing crystal / place crystal on obsidian / place obsidian then crystal -> strafe around target -> repeat.
One action per tick, every swap is a same-tick silent swap.

## Conflict policy
The bot waits (keys released, camera untouched, one chat notice) while any of these are toggled:
AutoPlaceCrystal, AutoHitCrystal, CrystalAura, CrystalMacro, ElytraCrystalBot, SwordAutoPlay, AutoPlay, ElytraMaceBot, KillAura, SurvivalBot, AutoClicker;
or while AutoTotem is swapping, a silent placement is pending, the player is using an item, or another module owns `RotationManager`.
If AutoTotem is on it owns the offhand; if it is off the bot re-equips the totem itself.

## Settings
Target Range, Min Health After Own Blast, D-Tap, No Damage Ticks (default 10), Random Delay (ms) min/max, Auto Golden Apple, Auto Ender Pearl,
Eat Health, Retreat Health, Aim Speed, plus Place/Break Range, Min Damage, Face Place Health, Require 2 Free Blocks,
Enemy Obsidian Estimate, Low Obsidian, Chat Log.

## Known limits (be honest)
* Enemy obsidian count is an ESTIMATE: assumed stack minus placements seen near them, plus drops near them.
* Enemy totem count is not observable; only pops are counted.
* Easy difficulty is treated as Normal in the damage model.
* Pearl throw uses a straight-ray clearance heuristic, not a landing simulation.
* Melee readiness uses `getAttackStrengthScale` of the currently held item.
* Movement (strafe / flee / pick-up) uses key presses relative to camera yaw.

## Verification status
* Pure rules: compiled with plain javac and `CrystalPvpSelfTest` passed (27 checks).
* Minecraft-facing code (`CrystalPvpBot`, the 3 static-ification edits, registration, th.txt): syntax-checked only. A full Gradle/Loom build was NOT run
  (no network / Minecraft jars in the build environment) and NOTHING was tested in a live game.
