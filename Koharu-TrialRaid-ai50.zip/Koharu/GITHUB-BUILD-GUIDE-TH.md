# Koharu — GitHub Build Kit (ภาษาไทย)

ชุดนี้เตรียมไว้ให้คุณนำโปรเจกต์ Koharu + Anubis Phase 10 Hardened ไปคอมไพล์ด้วย GitHub Actions โดยไม่ต้องติดตั้ง Java หรือ Gradle ในมือถือ/คอมของคุณ

## ไฟล์ในชุด

- `Koharu-Anubis-Integration-Phase10-Hardened.zip` — ซอร์สโปรเจกต์ต้นฉบับที่เตรียมไว้
- `build.yml` — workflow สำหรับ GitHub Actions

## วิธีตั้งค่าแบบอัปโหลด ZIP (เหมาะกับมือถือ)

1. แตกไฟล์ `Koharu-GitHub-Build-Kit.zip` ในเครื่องของคุณ แล้วเตรียมไฟล์สองไฟล์ด้านบน
2. เข้า https://github.com แล้วสร้าง Repository ใหม่ (จะตั้งเป็น Private ก็ได้)
3. เปิด Repository แล้วเลือก **Add file → Upload files** จากนั้นอัปโหลดไฟล์ `Koharu-Anubis-Integration-Phase10-Hardened.zip` ไปไว้ที่ root ของ Repository แล้วกด Commit changes
4. เลือก **Add file → Create new file**
5. ตั้งชื่อไฟล์เป็น `.github/workflows/build.yml`
6. เปิดไฟล์ `build.yml` ที่อยู่ในชุดนี้ คัดลอกเนื้อหาทั้งหมด แล้ววางลงในช่องแก้ไขไฟล์บน GitHub จากนั้นกด Commit changes
7. เปิดแท็บ **Actions** เลือก workflow **Koharu Fabric Build** แล้วกด **Run workflow** (หรือจะรอให้ workflow เริ่มทำงานหลัง Commit ก็ได้)
8. เมื่อสถานะเป็นสีเขียว ให้เปิดรายการ run นั้น เลื่อนลงไปที่ **Artifacts** แล้วดาวน์โหลด `Koharu-Minecraft-Mod-JAR`
9. แตก ZIP ของ Artifact แล้วนำไฟล์ `.jar` ที่ได้ไปใช้กับ Fabric ตามเวอร์ชันที่โปรเจกต์กำหนด

> Workflow นี้ตรวจหา source ZIP ที่ root ของ Repository และแตกไฟล์บน GitHub runner ให้เอง คุณไม่ต้องอัปโหลดไฟล์ Java หลายร้อยไฟล์ทีละไฟล์

## วิธีตั้งค่าแบบอัปโหลดซอร์สที่แตกแล้ว (เหมาะกับคอมพิวเตอร์)

แตก `Koharu-Anubis-Integration-Phase10-Hardened.zip` แล้วอัปโหลด **เนื้อหาภายในโฟลเดอร์ `Koharu-Survival-Autopilot` ทั้งหมด** ขึ้น root ของ Repository โดยต้องเห็น `gradlew`, `build.gradle`, `gradle.properties` และโฟลเดอร์ `gradle/` ที่ root จากนั้นเพิ่ม workflow ตามขั้นตอน 4–6

## Workflow ทำอะไรบ้าง

- ใช้ GitHub-hosted Ubuntu runner
- ติดตั้ง Eclipse Temurin JDK 21
- ใช้ Gradle Wrapper ของโปรเจกต์ ซึ่งกำหนด Gradle 9.2.1
- รัน `./gradlew clean test build --no-daemon --stacktrace`
- อัปโหลด JAR ที่ได้จาก `build/libs/` โดยไม่รวม `*-sources.jar`
- สร้างไฟล์ `SHA256SUMS.txt` สำหรับตรวจสอบไฟล์ JAR
- ถ้าบิลด์ล้มเหลว จะพยายามอัปโหลดรายงานทดสอบเพื่อช่วยหาสาเหตุ

ไม่ต้องตั้งค่า API key, GitHub secret หรือปลั๊กอิน AI สำหรับ workflow นี้

## ข้อควรรู้ก่อนใช้

- **ยังไม่มีการคอมไพล์ JAR ในชุดนี้** การคอมไพล์จริงจะเกิดขึ้นเมื่อคุณ Push/Run workflow ใน GitHub และต้องรอผลจาก Actions ก่อน
- การแพ็ก workflow ไม่ได้แก้หรือรับประกันว่าโค้ดทั้งหมดจะคอมไพล์ผ่าน หากเกิดปัญหา ให้เปิด run ที่ล้มเหลวใน Actions แล้วดู step แรกที่เป็นสีแดง
- รายงาน QA เดิมระบุว่าการทดสอบออฟไลน์บางส่วนผ่าน แต่ Full Gradle/Fabric build และการทดสอบเข้าเกมยังไม่ผ่านการยืนยัน เพราะเครื่องเดิมดาวน์โหลด Gradle ไม่ได้จากปัญหา DNS
- แพ็กเกจนี้สร้างจากซอร์ส Phase 10 Hardened ตามเดิม ไม่ได้เปลี่ยนรายการโมดูล Anubis ที่พอร์ตแล้ว และไม่ได้ตัด dependency llama.cpp ที่มีอยู่เดิมออกจาก `build.gradle` หากต้องการ build ที่ไม่มี dependency ดังกล่าว จะต้องทำการแก้ซอร์สแยกต่างหาก
- Workflow จะสร้าง JAR เท่านั้น ไม่ได้ยืนยันว่าเข้าเกม Minecraft หรือทำงานบนเซิร์ฟเวอร์เป้าหมายได้ ต้องทดสอบในโปรไฟล์เกมสำรองก่อนใช้งานจริง

## ถ้า Build ล้มเหลว

เปิด Repository → **Actions** → เลือก run ล่าสุด → เปิด job **Test and build Minecraft mod** แล้วดู step สีแดง คุณสามารถดาวน์โหลด Artifact ชื่อ `Koharu-Build-Diagnostics` ได้เมื่อมีรายงานทดสอบถูกสร้างขึ้น
