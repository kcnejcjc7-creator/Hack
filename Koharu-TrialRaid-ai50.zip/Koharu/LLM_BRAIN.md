# Koharu LLM brain (local model)

A language model running **on your own PC (or LAN)** acts as the strategic layer. It does not drive the keyboard or mouse.
Roughly once per second the mod sends a compact JSON description of the fight (your health/items, up to 5 nearby players, hazards,
what the controller is currently doing, damage dealt/taken). The model answers with a small JSON directive. The existing
`Planner` and combat bots still decide and execute everything tick by tick, and their safety rules always win.

## What the model can say

```json
{"mode":"AUTO|FIGHT|RETREAT|RECOVER","prefer":"<Planner action or NONE>","aggression":-1..1,"caution":0..1,"dodge":0..1,
 "focus":"<enemy name>","tactic":"<short text>","reason":"<short text>"}
```

All numbers are clamped, free text is truncated, unknown values are ignored, and a directive expires after about 3 intervals
(minimum 5 s). If the model is slow, offline, or returns junk, the directive lapses and the rule-based planner plays alone.

How the directive is applied (scaled by **LLM Influence**):
- `mode`: only `RETREAT` (always) and `RECOVER` (when health is below 18, you have apples and threat is low) change anything; the model cannot cancel a safety retreat.
- `prefer`: adds a bonus to that action **only if the action is already applicable** (e.g. HEAL needs apples). Unsafe actions stay blocked.
- `aggression` / `caution` / `dodge`: small additive nudges to ATTACK / RETREAT / STRAFE+BLOCK scores.
- `focus`: makes that player more attractive as the target among nearby enemies.

## Setup

**Ollama**
1. Install Ollama, then `ollama pull qwen2.5:7b-instruct` (any instruct model works; avoid slow "thinking" models).
2. Make sure it is running (default `http://127.0.0.1:11434`).
3. In the KoharuAI module: `LLM Brain` on, `LLM Backend` = Ollama, `LLM Model` = the model name (default `qwen2.5:7b-instruct`), leave `LLM URL` blank.

**LM Studio**
1. Load a model, then start the local server (Developer tab, default `http://127.0.0.1:1234`).
2. `LLM Backend` = LM Studio, `LLM Model` = the loaded model's identifier, `LLM URL` blank (or your address).

Check it with `/koharuai llm-test` then `/koharuai llm-status` (shows backend, URL, model, latency, last error and the current directive).
The debug HUD shows the same status in one line.

## Settings

| Setting | Meaning |
|---|---|
| LLM Brain | master switch |
| LLM Backend | Ollama (`/api/chat`) or LM Studio / OpenAI-compatible (`/v1/chat/completions`) |
| LLM URL | blank = backend default; otherwise base URL such as `http://192.168.1.20:11434` |
| LLM Model | model name sent to the server |
| LLM Interval | ticks between requests (20 ticks = 1 s) |
| LLM Timeout | seconds before a request is abandoned |
| LLM Influence | 0 = ignore the model, 1 = full strength (default 0.7) |

## Safety and privacy

- One request at a time on a background thread; the game thread never waits for the model.
- Only loopback and private-network addresses are contacted (127.x, 10.x, 172.16-31.x, 192.168.x, link-local). Anything else is refused before connecting, so game state (player names, health, positions-derived data) is never sent over the internet. Redirects are not followed.
- Failures back off exponentially (2 s up to 30 s).

## Honest limits

- Tested only against mock servers (`tools/LlmBrainHttpTest.java`) and unit tests. Not tested with a real model, in a real client, or in a real fight.
- A 7B-class local model has seconds of latency on modest hardware and no learned PvP skill; it reasons from the summary text only. Whether it improves results over the rule planner alone is unmeasured: compare with `LLM Influence` at 0 versus 0.7 in private fights.
- This layer cannot make the bot "as smart as Gemini or GPT" at aiming, timing or movement; those stay in the controller. Larger models raise latency, which is why directives are advisory and expire.

## Running the tests

```bash
SRC=src/client/java/com/koharu/koharuclient/client/ai
javac -d /tmp/out $(grep -L "net.minecraft\|client.module\|client.utils\|KoharuClient" $SRC/*.java) tools/LlmBrainHttpTest.java
java -ea -cp /tmp/out com.koharu.koharuclient.client.ai.AiCoreSelfTest
java -cp /tmp/out LlmBrainHttpTest
```
