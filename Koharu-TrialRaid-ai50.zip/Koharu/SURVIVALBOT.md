# SurvivalBot + Baritone Autopilot (experimental)

Koharu now compiles Baritone's API/runtime/mixins into the same Fabric mod. There is no second Baritone JAR to install manually.

## What is integrated

- `SurvivalBot` remains the progression planner and handles the existing Wood / Stone / Iron / Diamond gear kits.
- Baritone supplies pathfinding and long-range mining for logs, stone/cobblestone, coal, iron ore and diamond ore.
- When Baritone cannot start a mine route or releases its process, the previous local scanner / step planner is retained as a fallback.
- Crafting-table and furnace workflows stay in Koharu's existing SurvivalBot implementation.
- The Baritone mixin config is loaded by Koharu and its default `#` chat prefix remains enabled. Commands such as `#help`, `#mine`, `#goto`, and `#cancel` are still handled by Baritone.
- `Progress HUD` displays the selected kit, completed gear goals, current task, navigation status, health and hunger. `Baritone Pathing` can be switched off to use the old local movement/mining fallback.

## Use

1. Build Koharu using Java 21 and `./gradlew build`.
2. Put the resulting `koharuclient-<version>.jar` in the Fabric `mods` folder. Do not add a separate Baritone JAR from this source bundle.
3. Join a single-player or permitted private world.
4. Open Koharu's module GUI, enable `SurvivalBot`, choose a kit, and leave `Progress HUD` on to watch the task state.
5. Type Baritone commands in chat with `#`, as before.

## Current limits — important

This integration is **not yet** the full end-to-end campaign requested for all endgame equipment. The current planner still completes only its existing Wood, Stone, Iron or Diamond kit. It does not yet autonomously locate/clear villages and trade routes, run enchanting, enter and loot the Nether, mine ancient debris or apply netherite upgrades, locate/clear trial chambers for the mace, or reach the End and obtain an elytra. It also does not yet automate food gathering/eating, brewing or a complete combat loop. Those require separate progression tasks and world-interaction routines; they are not silently treated as complete.

The game-facing SurvivalBot logic has not been verified in a live Minecraft client in this environment. Baritone's pathfinding source and the pure-Java SurvivalPlanner/StepPlanner self-tests are present, but the full Fabric Gradle build could not be run here because the Gradle wrapper distribution and Maven dependencies require network access. Test in a disposable single-player world first, and check server rules before using automation on multiplayer servers.

## Source and licensing

Baritone sources are vendored in `third_party/baritone/` from the supplied 1.21.11 source archive. Their LGPL-3.0 license is included as `third_party/baritone/LICENSE` and is copied into the built JAR as `LICENSE-BARITONE`. Koharu's original license and notices remain in place.
