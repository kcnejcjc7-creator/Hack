# Third-party notices

## Baritone

This project includes Baritone source files under `third_party/baritone/`.
Baritone is licensed under GNU Lesser General Public License, version 3 or later (LGPL-3.0-or-later).
See `third_party/baritone/LICENSE` for the full license text. The original source project and attribution are retained in that directory.

Baritone's `dev.babbaj:nether-pathfinder:1.6` dependency is declared in Gradle and included in the produced Fabric mod through Fabric's nested dependency mechanism.

## Anubis (integration reference)

Anubis 0.9.9 by 4ldenz was reviewed as an integration reference; its source archive declares `GPL-3.0-only` and identifies Minecraft 1.21.11. Phase 10's `CoordSnapper` and `RenderDistanceToggle` were reimplemented against Koharu's Mojang-mapped module/settings APIs. The Anubis `ClientModule`, EventBus, entrypoint and mixin framework are not bundled as runtime dependencies in this release candidate. See `ANUBIS-AUDIT-TH.md` for the feature-by-feature compatibility inventory.
